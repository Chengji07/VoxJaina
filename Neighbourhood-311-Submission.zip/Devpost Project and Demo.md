# Neighbourhood 311

**Tagline**  
Report city issues in your own language.

**Track**  
[ElevenLabs] Best Voice of Mississauga

## Project description

### Inspiration

A streetlight report can go to the wrong place if a voice system mishears a single digit. We asked which Mississauga communities the available speech data lets us test and how a resident could recover when a voice report is misheard.

### What we found

We joined 2021 Census home-language counts to the competition pack’s spoken-request coverage. Among 153,480 residents across the 14 profiled non-official home languages, 79,940 (52.1%) most often spoke one of eight languages with zero request clips in the pack. Ward 5 had the largest gap by count, at about 16,300 residents. The counts measure coverage in two provided request datasets and cannot estimate local 311 error rates.

### What it does

Neighbourhood 311 is an English-interface prototype for reporting a broken streetlight by voice in Mandarin. A resident can record audio or play a built-in example, check the detected address, correct it and preview the updated report. They can also try a simulated Mandarin interpreter request. Live mode sends a Mandarin recording to ElevenLabs Scribe v2 and drafts an editable English report. The offline sample uses a simulated transcription. City submission and interpreter routing are simulated.

The companion Voice Access Lab includes 15 human-read FLEURS clips and their reference transcripts. It compares reference text with imported ElevenLabs Scribe v2 output and reports character error rate. The included runner supports an initial five-clip pilot with one matched sentence across English, Urdu, Punjabi, Mandarin and Cantonese. Report measured outcomes only after completing the run.

### Sources

- [City of Mississauga Open Data](https://data.mississauga.ca/) — 2021 Census, as processed in the competition pack. Contains information provided by the City of Mississauga.
- [Google FLEURS](https://huggingface.co/datasets/google/fleurs) — Conneau et al. (2022), human-read speech and reference text. [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
- [MInDS-14](https://huggingface.co/datasets/PolyAI/minds14) and [Speech-MASSIVE](https://huggingface.co/datasets/FBK-MT/Speech-MASSIVE) — request coverage counts.
- [ElevenLabs Scribe API](https://elevenlabs.io/docs/api-reference/speech-to-text/convert) — transcription workflow.

## Two-minute sample demo

Open Neighbourhood 311 and Voice Access Lab in separate tabs. This walkthrough uses the built-in sample and requires no live microphone recording or API key.

### 0:00–0:20 · Introduce the app

Show the homepage. “Neighbourhood 311 helps residents report city issues in Mandarin and review an English report before submitting.”

### 0:20–1:15 · Play the sample and show the translation

Under **Try a Mandarin sample**, press play, then click **Use sample and continue**. Point to the open **View original Mandarin transcript** panel, then to **English description**.

“This is a prerecorded Mandarin sample. Here is the Mandarin transcript and its English translation. The speaker is reporting a broken streetlight at 120 Maple Street. The texts on this screen are preloaded for the demo.”

### 1:15–1:40 · Correct the address

Point to **Detected address**. “We’ve simulated an address error to show how a resident can fix it.” Change **12 Maple Street** to **120 Maple Street**, click **Save address**, then **Confirm and preview**. Show the corrected English report.

### 1:40–2:00 · Show the data

Open Voice Access Lab. “Among the residents whose home languages we profiled, 52.1 percent speak a language with no request recordings in this pack. This shows where we need more examples to test multilingual reporting.”

## Upload checklist

1. Open [Sheridan Datathon on Devpost](https://sheridandatathon2026.devpost.com/). Open your existing project draft and confirm **[ElevenLabs] Best Voice of Mississauga** is selected. The published draft cutoff was Saturday, November 7 at 8:00 p.m. Toronto time.
2. Add the project name, tagline, short description and all team members. Use your own name if you entered solo.
3. Publish the unpacked project files to a public repository and add the repository URL. The source ZIP is ready to unpack. Devpost also accepts a notebook, dashboard or written analysis.
4. Record the two-minute demo and upload it to public YouTube or a Google Drive link that judges can open. Paste the video URL into Devpost.
5. Check both links in a private browser window. Submit by Sunday, November 8 at noon Toronto time and check Devpost for confirmation.
